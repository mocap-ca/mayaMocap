

arduinoNode = None
arduinoIP = '192.168.1.91'
arduinoPort = 10499

motiveRepeaterPort = 9119

arudinoDataPort = 11200

localIP = '192.168.1.9'
#localIP = '192.168.1.22'


plugin = 'C:\\cpp\\git\\github\\mayaMocap\\plugin\\build_vs2015\\x64\\Debug\\build_vs2015.mll'